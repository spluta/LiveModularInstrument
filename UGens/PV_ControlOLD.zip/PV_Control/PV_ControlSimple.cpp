#include "FFT_UGens.h"
//#include <stdio.h>

InterfaceTable *ft;

struct PV_Control : Unit
{
	int m_numbins;
	float *m_mags, *m_mulArray, *m_addArray;
	int *m_waitArray;
};

extern "C"
{
	void PV_Control_Ctor(PV_Control *unit);
	void PV_Control_next(PV_Control *unit, int inNumSamples);
	void PV_Control_Dtor(PV_Control *unit);
}


void PV_Control_Ctor(PV_Control* unit)
{
	SETCALC(PV_Control_next);
	ZOUT0(0) = ZIN0(0);
	unit->m_mags = 0;
}

void PV_Control_next(PV_Control *unit, int inNumSamples)
{
	PV_GET_BUF

	float threshold = ZIN0(1);
	float mulFactor = ZIN0(2);
	float limiter = ZIN0(3);
	int attackReleaseFrames = ZIN0(4);
	int sustainZeroFrames = ZIN0(5);
	int highestBin = ZIN0(6);
	
	if (!unit->m_mags) {
		//alloc the arrays
		unit->m_mags = (float*)RTAlloc(unit->mWorld, numbins * sizeof(float));
		unit->m_mulArray = (float*)RTAlloc(unit->mWorld, numbins * sizeof(float));
		unit->m_addArray = (float*)RTAlloc(unit->mWorld, numbins * sizeof(float));
		unit->m_waitArray = (int*)RTAlloc(unit->mWorld, numbins * sizeof(int));

		for (int i=0; i<numbins; ++i) {
			unit->m_mags[i] = 0.f;
			unit->m_mulArray[i] = 1.0f;
			unit->m_addArray[i] = 0.f;
			unit->m_waitArray[i] = 0;
		}

		//unit->counterArray = (int*)RTAlloc(unit->mWorld, numbins * sizeof(int));
		
		unit->m_numbins = numbins;
	} else if (numbins != unit->m_numbins) return;

	SCPolarBuf *p = ToPolarApx(buf);

	float *mags = unit->m_mags;
	float *mulArray = unit->m_mulArray;
	float *addArray = unit->m_addArray;
	int *waitArray = unit->m_waitArray;

	//traverse the array and find the summed magnitude
	for (int i=0; i<numbins; ++i) {
		mags[i] = (mags[i]+p->bin[i].mag)*mulFactor;
	}

	//if the mag is over the threshold, reduce the mag to 0
	for (int i=0; i<highestBin; ++i) {
		if (waitArray[i]==0){
			if(mulArray[i]==0){
				addArray[i] = (float)(1/(float)attackReleaseFrames);
			}
			else if(mags[i]>threshold){
				addArray[i] = (float)(-1/(float)attackReleaseFrames);
			}

			if (addArray!=0){
				mulArray[i] += addArray[i];
				if (mulArray[i]<0)
				{
					mulArray[i] = 0;
					addArray[i] = 0;
					waitArray[i] = sustainZeroFrames;
				}
				else if (mulArray[i]>1){
					mulArray[i] = 1;
					addArray[i] = 0;
				}
			}

		}
		else waitArray[i]--;
	}

	

	for (int i=0; i<numbins; ++i) {
		p->bin[i].mag = p->bin[i].mag * mulArray[i];

		//limiter
		if(p->bin[i].mag>limiter)
			p->bin[i].mag=limiter;
	}

	//get rid of the highest bins
	for (int i=highestBin; i<numbins; ++i) {
		p->bin[i].mag = 0;
	}

}

void PV_Control_Dtor(PV_Control* unit)
{
	RTFree(unit->mWorld, unit->m_mags);
}

#define DefinePVUnit(name) \
(*ft->fDefineUnit)(#name, sizeof(PV_Unit), (UnitCtorFunc)&name##_Ctor, 0, 0);

PluginLoad(PV_Control)
{
    // InterfaceTable *inTable implicitly given as argument to the load function
    ft = inTable; // store pointer to InterfaceTable
    //init_SCComplex(inTable);

    DefineDtorUnit(PV_Control);
}